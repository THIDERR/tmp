var fs = require('fs');
var http = require('http');
var express = require('express'),
app = module.exports.app = express();
var server = http.createServer(app);
var io = require('socket.io').listen(server);
server.listen(8888);
var ext=require('path');
ent = require('ent');

app.use('/style', express.static(__dirname + '/style'));
app.use('/js', express.static(__dirname + '/js'));
app.use('/views', express.static(__dirname + '/views'));

app.get('/Home', function(req, res) {
	fs.readFile('./views/index.html', 'utf-8', function(error, content) {
		res.end(content);
	});
});
app.get('/Workspaces', function(req, res) {
	fs.readFile('./views/workspaces.html', 'utf-8', function(error, content) {
		res.end(content);
	});
});
app.get('/ToDo', function(req, res) {
	fs.readFile('./views/todoList.html', 'utf-8', function(error, content) {
		res.end(content);
	});
});
app.get('/Music', function(req, res) {
	fs.readFile('./views/music.html', 'utf-8', function(error, content) {
		res.end(content);
	});
});


app.use(function(req, res, next){
	res.redirect('Home');
});


io.sockets.on('connection', function (socket) {
	
	// nav top
	socket.on('getAllWorkspaces', function (repertory) {
		var path = './'+repertory+'';
		fs.readdir(path, function(err, items) {
			for (var i=0; i<items.length; i++) {
				socket.emit('setWorkspace', items[i]);
			}
		});
	});
	
	// nav left
	socket.on('getAllProjects', function (repertory) {
		var path = './workspaces/'+repertory;
		fs.readdir(path, function(err, items) {
			for (var i=0; i<items.length; i++) {
				ssMenu(items[i], path);
			}
		});
	});

	// affiche le sous sous-menu
	socket.on('getMenu', function (path) {
		fs.readdir(path, function(err, items) {
			for (var i=0; i<items.length; i++) {
				ssMenu2(items[i], path);
			}
		});
	});

	// renvoie la source
	socket.on('getSourceCode', function (path) {
		socket.emit('setSrcContent', fs.readFileSync(path, 'utf8'), ext.extname(path));
	});


	// sous nav left
	function ssMenu(item1, tmpPath){
		fs.readdir(tmpPath+'/'+item1, function(err, item2) {
			if (item2){
				socket.emit('setProject',item1 , true, tmpPath+'/'+item1);
			}
			else{
				socket.emit('setProject',item1 , false, tmpPath+'/'+item1);
			}
		});
	}


	// sous sous nav
	function ssMenu2(item1, tmpPath){
		fs.readdir(tmpPath+'/'+item1, function(err, item2) {
			if (item2){
				socket.emit('setSubMenu',item1 , true, tmpPath+'/'+item1);
			}
			else{
				socket.emit('setSubMenu',item1 , false, tmpPath+'/'+item1);
			}
		});
	}

	var controllerTodo = require('./controllers/todo');
	controllerTodo.todoController(socket, todo);
});

