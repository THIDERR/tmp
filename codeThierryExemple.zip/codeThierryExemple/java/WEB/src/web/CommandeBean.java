package web;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import pdf.PdfGen;
import service.ServiceException;
import service.ServiceRemote;
import domain.Adresse;
import domain.Commande;
import domain.Piece;

@SessionScoped
@ManagedBean
public class CommandeBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@EJB
	private ServiceRemote service = null;
	
	private String pdf;
	private int indice;
	
	
	
	@NotNull (message ="Obligatoire")
	@Size(min = 2, max = 16, message ="Entre 2 et 16 caracteres")
	private String nom;
	
	@NotNull (message ="Obligatoire")
	@Size(min = 2, max = 16, message ="Entre 2 et 16 caracteres")
	private String prenom;
	
	@NotNull
	@Pattern(regexp = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)+$", message="Mail invalide")
	private String mail;
	
	@NotNull (message ="Obligatoire")
	@Size(min = 2, max = 16, message ="Entre 2 et 16 caracteres")
	private String rue;
	
	@NotNull (message ="Obligatoire")
	@Size(min = 2, max = 16, message ="Entre 2 et 16 caracteres")
	private String ville;
	
	@NotNull (message ="Obligatoire")
	@Size(min = 5, max = 5, message ="5 Chiffres")
	private String codePostal;
	
	@NotNull (message ="Obligatoire")
	private int tel;
	
	
	private List<Piece> panier;
	private String msgFormLiv;
	
	
	@PostConstruct
	public void init() {indice = 3;}
	public CommandeBean() {}
	public String next(String link, int indice) {
		this.indice = indice;
		return link;
	}
	public String next(String link, int indice, List<Piece> panier) {
		
		this.indice = indice;
		this.panier = panier;
		return link;
	}
	
	
	
	
	public String validerFormLivraison(){
		
		this.indice = 2;
		return "paiement.jsf";
	}
	public String confirmer(String link, int indice) {
		try {
			this.indice++;
			Adresse address = new Adresse();
			Commande cmd = new Commande();
			address.setAdressComp(rue);
			address.setCodepostal(codePostal);
			address.setNom(nom);
			address.setPrenom(prenom);
			address.setVille(ville);
			address = service.insertAdresse(address);
			cmd.setAdresse_facturation(address);
			cmd.setAdresse_livraison(address);
			cmd.setEmail(mail);
			cmd.setPieces(panier);
			cmd.setTel(tel);
			cmd = service.insertCommande(cmd);
			pdf = "D:\\eclipseProject\\Pr03JSF2\\WebContent\\pdf\\"
					+ cmd.getId() + ".pdf";
			String tmpLink = "http://localhost:8080/Pr03JSF2/pdf/"
					+ cmd.getId() + ".pdf";
			new PdfGen(pdf, cmd);
			((HttpSession) FacesContext.getCurrentInstance()
					.getExternalContext().getSession(true)).invalidate();
			((HttpSession) FacesContext.getCurrentInstance()
					.getExternalContext().getSession(true)).setAttribute(
					"facture", tmpLink);
			
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return link;
	}
	public int getIndice() {
		return indice;
	}
	public void setIndice(int indice) {
		this.indice = indice;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getRue() {
		return rue;
	}
	public void setRue(String rue) {
		this.rue = rue;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public String getCodePostal() {
		return codePostal;
	}
	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}
	public List<Piece> getPanier() {
		return panier;
	}
	public void setPanier(List<Piece> panier) {
		this.panier = panier;
	}

	public ServiceRemote getService() {
		return service;
	}
	public void setService(ServiceRemote service) {
		this.service = service;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
	public String getPdf() {
		return pdf;
	}
	public void setPdf(String pdf) {
		this.pdf = pdf;
	}
	public String getMsgFormLiv() {
		return msgFormLiv;
	}
	public void setMsgFormLiv(String msgFormLiv) {
		this.msgFormLiv = msgFormLiv;
	}
}
