package web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import service.ServiceException;
import service.ServiceRemote;
import web.MarqueBean.ColumnModel;
import domain.Marque;
import domain.Modele;
import domain.Piece;
import domain.Type;

@ViewScoped
@ManagedBean
public class PieceBean implements Serializable{

	@EJB
	private ServiceRemote svc=null;
	private static final long serialVersionUID = 1L;
    private List<Piece> contenu;
    private int id;
    private String nom;
    private int j;
    private Modele mod;

	@PostConstruct
    public void init() {
		createDynamicColumns();
		contenu=null;	
    }
	
	public Modele getMod() {
		return mod;
	}


	public void setMod(Modele mod) {
		this.mod = mod;
	}


	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

    /********************************************************/ 
	public String getNom() {
		return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/********************************************************/ 
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	/********************************************************/ 
	public List<Piece> getContenu() {
		return contenu;
	}
	
	/********************************************************/ 
	public void setContenu(List<Piece> contenu) {
		this.contenu = contenu;
	}
	
	 /********************************************************/
		public String getPieceByM(String mo){
			try {

				mod=svc.getModeleByLibelle(mo);
				contenu=svc.getPiecesByModele(mod);
				setJ(contenu.size());
				//System.out.println(contenu);
			} catch (ServiceException e) {
				e.printStackTrace();
			}
			return "";
		}
		
		
		
		/*datatable-dynamic columns********************************************************/
		private final static List<String> VALID_COLUMN_KEYS = Arrays.asList("id", "reference", "prix", "categorie");
		private String columnTemplate = "id reference prix categorie";
		private List<ColumnModel> columns;
		private List<Marque> filteredMarque;
		
		public String getColumnTemplate() {
	        return columnTemplate;
	    }
	 
	    public void setColumnTemplate(String columnTemplate) {
	        this.columnTemplate = columnTemplate;
	    }
	 
	    public List<ColumnModel> getColumns() {
	        return columns;
	    }
	    
	    public List<Marque> getFilteredMarque() {
	        return filteredMarque;
	    }
	 
	    public void setFilteredMarque(List<Marque> filteredMarque) {
	        this.filteredMarque = filteredMarque;
	    }
	 
	    private void createDynamicColumns() {
	        String[] columnKeys = columnTemplate.split(" ");
	        columns = new ArrayList<ColumnModel>();   
	         
	        for(String columnKey : columnKeys) {
	            String key = columnKey.trim();
	             
	            if(VALID_COLUMN_KEYS.contains(key)) {
	                columns.add(new ColumnModel(columnKey.toUpperCase(), columnKey));
	            }
	        }
	    }
	    
	    public void updateColumns() {
	        //reset table state
	        UIComponent table = FacesContext.getCurrentInstance().getViewRoot().findComponent(":dt2:contenu");
	        table.setValueExpression("sortBy", null);
	         
	        //update columns
	        createDynamicColumns();
	    }
		
	    static public class ColumnModel implements Serializable {
			 
	        private String header;
	        private String property;
	 
	        public ColumnModel(String header, String property) {
	            this.header = header;
	            this.property = property;
	        }
	 
	        public String getHeader() {
	            return header;
	        }
	 
	        public String getProperty() {
	            return property;
	        }
	    }
   
}
