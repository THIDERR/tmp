package web;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ViewScoped
@ManagedBean
public class NavigationBean  implements Serializable{
	private static final long serialVersionUID = 1L;

	public String panier(){
		return "panier.jsf";
	}
	public String livraison(){
		return "livraison.jsf";
	}
	
}
