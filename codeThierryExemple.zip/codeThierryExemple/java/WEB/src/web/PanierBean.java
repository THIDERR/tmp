package web;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import service.PanierRemote;
import service.ServiceException;
import service.ServiceRemote;
import domain.Piece;

@SessionScoped
@ManagedBean
public class PanierBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@EJB
	private PanierRemote servicePan = null;
	@EJB
	private ServiceRemote service = null;
	private List<Piece> panier;
	@PostConstruct
	public void init() {
		try {
			panier = servicePan.getContenuPanier();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public PanierBean() {
	}
	
	public void refresh(){
		try {
			panier = servicePan.getContenuPanier();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void ajouter(String ref) {
		try {
			servicePan.ajoutePiecePanier(service.getPiecesByRef(ref).get(0), 1);
			panier = servicePan.getContenuPanier();

		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void enlever(String ref) {
		System.out.println("enleverPi");
		try {
			servicePan.enlevePiecePanier(service.getPiecesByRef(ref).get(0));
			panier = servicePan.getContenuPanier();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<String> completeText(String query) {
        List<String> results = new ArrayList<String>();
        for(int i = 0; i < 10; i++) {
            results.add(query + i);
        }
         
        return results;
    }
	
	public int isEmpty(){
		if(this.panier.isEmpty()==true){
			return 1;
		}else{
			return 0;
		}
	}
	
	public int incrementer(int qte){
		qte=qte+1;
		return qte;
	}
	
	public int decrementer(int qte){
		if(qte>0){
			qte=qte-1;
		}else{
			qte=0;
		}
		return qte;
	}
	
	public PanierRemote getServicePan() {
		return servicePan;
	}

	public void setServicePan(PanierRemote servicePan) {
		this.servicePan = servicePan;
	}

	public List<Piece> getPanier() {
		return panier;
	}

	public void setPanier(List<Piece> panier) {
		this.panier = panier;
	}
	public ServiceRemote getService() {
		return service;
	}
	public void setService(ServiceRemote service) {
		this.service = service;
	}
}
