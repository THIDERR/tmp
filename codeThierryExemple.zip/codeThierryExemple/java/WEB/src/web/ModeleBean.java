package web;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import service.ServiceException;
import service.ServiceRemote;
import domain.Modele;
import domain.Type;
import domain.Marque;

@ViewScoped
@ManagedBean
public class ModeleBean implements Serializable{
	
	@EJB
	private ServiceRemote svc=null;
	private static final long serialVersionUID = 1L;
    private List<Modele> contenu;
    private int id;
    private String nom;
    private Modele mod;
    
   
    /********************************************************/   
    public Modele getMod() {
		return mod;
	}

	public void setMod(Modele mod) {
		this.mod = mod;
	}

	 /********************************************************/
	public String getModeleMT(String ma, String ty){
		try {
			Marque m=svc.getMarqueByLibelle(ma);
			Type t=svc.getTypeByLibelle(ty);
			contenu=svc.getModeleByMaTy(m, t);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return "";
	}
    
    /********************************************************/
	public ServiceRemote getSvc() {
		return svc;
	}
	
	public void setSvc(ServiceRemote svc) {
		this.svc = svc;
	}
	
	 /********************************************************/
	public List<Modele> getContenu() {
		return contenu;
	}
	
	public void setContenu(List<Modele> contenu) {
		this.contenu = contenu;
	}
	
	 /********************************************************/
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	 /********************************************************/
	public String getNom() {
		return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}

    
}
