package web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import service.ServiceException;
import service.ServiceRemote;
import domain.Marque;
import domain.Modele;
import domain.Piece;
import domain.Type;

@SessionScoped
@ManagedBean
public class HomeBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@EJB
	private ServiceRemote service = null;
	private List<Modele> listMo;
	private List<Piece> listePi;
	private Marque mrq;
	private Type ty;
	private int nbResult;
	String str;
	private int id;
    private String nom;
	
    @PostConstruct
	public void init() {
		try {
			listePi = new ArrayList<Piece>();
			mrq = service.getMarqueByLibelle("MOULINEX");
			ty = service.getTypeByLibelle("Blender");
			str = "Blender";
			listMo = service.getModeleByMaTy(mrq, ty);
			for (Modele mo : listMo) {
				for (Piece pi : service.getPiecesByModele(mo)) {
					listePi.add(pi);
				}
			}
			nbResult = listePi.size();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	public HomeBean() {	}
	public void refresh() {
		try {
			Modele mo = null;
			listePi = new ArrayList<Piece>();
			nbResult = 0;
			listMo = service.getModeleByMaTy(
					service.getMarqueByLibelle(mrq.getNom()),
					service.getTypeByLibelle(ty.getNom()));
			for (int i = 0; i < listMo.size(); i++) {
				mo = listMo.get(i);
				listMo.get(i).setPieces(service.getPiecesByModele(mo));
				for (Piece pi : service.getPiecesByModele(mo)) {
					listePi.add(pi);
				}
			}
			nbResult = listePi.size();
			System.out.println(listMo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	public List<String> completeType(String query) {
		str = query;
		try {
			List<String> results = new ArrayList<String>();
			for (Type t : service.getAllType()) {
				if ((results.size() < 10)
						&& (t.getNom().matches("(?i:.*" + query + ".*)")))
					results.add(t.getNom());
				if (query.equalsIgnoreCase(t.getNom())) {
					ty = t;
					refresh();
				}
			}
			if (results.size() == 1) {
				ty = service.getTypeByLibelle(results.get(0));
				refresh();
			}
			return results;
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<String> completeMarque(String query) {
		try {
			List<String> results = new ArrayList<String>();
			for (Marque m : service.getAllMarque())
				if ((results.size() < 10)
						&& (m.getNom().matches("(?i:.*" + query + ".*)")))
					results.add(m.getNom());
			mrq.setNom(query);
			return results;
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return null;
	}
	public ServiceRemote getService() {
		return service;
	}
	public void setService(ServiceRemote service) {
		this.service = service;
	}
	public List<Piece> getListePi() {
		return listePi;
	}
	public void setListePi(List<Piece> listePi) {
		this.listePi = listePi;
	}
	public Marque getMrq() {
		return mrq;
	}
	public void setMrq(Marque mrq) {
		this.mrq = mrq;
		//refresh();
	}
	public List<Modele> getListMo() {
		return listMo;
	}
	public void setListMo(List<Modele> listMo) {
		this.listMo = listMo;
	}
	public Type getTy() {
		return ty;
	}
	public void setTy(Type ty) {
		this.ty = ty;
	}
	public int getNbResult() {
		return nbResult;
	}
	public void setNbResult(int nbResult) {
		this.nbResult = nbResult;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
}
