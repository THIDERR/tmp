package rest;


import java.util.List;



// imports EJB
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import domain.Marque;
import service.ServiceException;
import service.ServiceRemote;

/**
 * Session Bean implementation class Service
 */
@Stateless
public class RestService implements WSService{

	/*@EJB(lookup="ejb:/EJB3W/Service!mesServices.ServiceRemote")*/
	
	@EJB(lookup="java:global/Pr03JSF2/Service!service.ServiceRemote")
	private ServiceRemote svcR;


	// Services EJB Marque ====================================================

	public List<domain.Marque> getAllMarques() {
		try {
			return svcR.getAllMarque();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return null;
		
	}

	public Marque insert(String mrq) throws ServiceException {
		Marque mr=new Marque();
		if (mrq == null){
			System.out.println("mrq null!");
		}
		else{
			mr.setNom(mrq);
			try{
				mr=svcR.insertMarque(mr);
			}
			catch(EJBException e){
				throw new ServiceException("erreur insert(Marque m)",1);
			}
		}
		return mr;
	}

	public void delete(String mrq) throws ServiceException {
		try {
			Marque m=getBy(mrq);
			svcR.deleteMarque(m);
		} catch (Exception e) {
			throw new ServiceException("erreur delete(Marque m)",1);
		}
	}

	public Marque getBy(String mqr){
		try {
			return svcR.getMarqueByLibelle(mqr);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


}
