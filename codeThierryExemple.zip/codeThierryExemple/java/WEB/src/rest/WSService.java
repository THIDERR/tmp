package rest;


import java.util.List;

//imports REST
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import service.ServiceException;
import domain.Marque;


/**
 * Session Bean implementation class Service
 */

@Path("/marques")

public interface WSService {


	// Services EJB Marque ====================================================

	@GET
	@Produces("application/json")
	public List<Marque> getAllMarques();

	@POST
	//@Consumes({"application/json","application/x-www-form-urlencoded"})
	@Consumes("application/json")
	@Produces("application/json")
	public Marque insert(String mrq) throws ServiceException;

	@GET
	@Path("/{marqueNom}")
	@Produces("application/json")
	public Marque getBy(@PathParam("marqueNom") String marqueNom);

	@DELETE
	@Path("/{marqueNom}")
	public void delete(@PathParam("marqueNom") String marqueNom) throws ServiceException;
	
}
