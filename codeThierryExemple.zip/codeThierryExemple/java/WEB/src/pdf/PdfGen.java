package pdf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Date;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import domain.Commande;

public class PdfGen {
	public PdfGen(String link, Commande cmd) {
		try {
			OutputStream file = new FileOutputStream(new File(link));
			Document document = new Document();
			PdfWriter.getInstance(document, file);
			// Inserting Image in PDF
			Image image = Image
					.getInstance("http://localhost:8080/Pr03JSF2/img/smb.png");
			image.scaleAbsolute(120f, 60f);// image width,height
			// Inserting Table in PDF
			PdfPTable table = new PdfPTable(2);
			PdfPCell cell = new PdfPCell(new Paragraph("Facture #"
					+ cmd.getId()));
			cell.setColspan(2);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setPadding(10.0f);
			cell.setBackgroundColor(new BaseColor(140, 221, 8));
			table.addCell(cell);
			table.addCell("Nom");
			table.addCell(cmd.getAdresse_facturation().getNom());
			table.addCell("Prenom");
			table.addCell(cmd.getAdresse_facturation().getPrenom());
			table.addCell("Addresse");
			table.addCell(cmd.getAdresse_facturation().getAdressComp());
			table.addCell("Ville");
			table.addCell(cmd.getAdresse_facturation().getVille());
			table.addCell("Code Postal");
			table.addCell(cmd.getAdresse_facturation().getCodepostal());
			table.addCell("Montant TTC");
			table.addCell("a ajouter");
			table.setSpacingBefore(30.0f); // Space Before table starts, like
											// margin-top in CSS
			table.setSpacingAfter(30.0f); // Space After table starts, like
											// margin-Bottom in CSS
			// Inserting List in PDF
			List list = new List(true, 30);
			list.add(new ListItem("Java4s"));
			list.add(new ListItem("Php4s"));
			list.add(new ListItem("Some Thing..."));
			// Text formating in PDF
			Chunk chunk = new Chunk(
					"Nous vous remercions de votre commande en cas de probleme appelez nous au ");
			chunk.setUnderline(+1f, -2f);// 1st co-ordinate is for line
											// width,2nd is space between
			Chunk chunk1 = new Chunk("0800 800 800");
			chunk1.setUnderline(+4f, -8f);
			chunk1.setBackground(new BaseColor(17, 46, 193));
			// Now Insert Every Thing Into PDF Document
			document.open();// PDF document opened........
			document.add(image);
			document.add(Chunk.NEWLINE); // Something like in HTML :-)
			document.add(new Paragraph("Monsieur, Madamme "
					+ cmd.getAdresse_facturation().getNom()));
			document.add(new Paragraph("Facture de la commande effectuée le - "
					+ new Date().toString()));
			document.add(table);
			document.add(chunk);
			document.add(chunk1);
			document.add(Chunk.NEWLINE); // Something like in HTML :-)
			document.newPage(); // Opened new page
			document.add(list); // In the new page we are going to add list
			document.close();
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}