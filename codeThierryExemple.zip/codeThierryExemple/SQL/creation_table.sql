-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 24 Mars 2017 à 11:35
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `b14`
--
--
-- Structure de la table `adresse`
--

CREATE TABLE IF NOT EXISTS `adresse` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ADRESS` varchar(255) DEFAULT NULL,
  `CODEPOSTAL` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `NOM` varchar(255) DEFAULT NULL,
  `PRENOM` varchar(255) DEFAULT NULL,
  `TEL` int(11) DEFAULT NULL,
  `VILLE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=160 ;

-- --------------------------------------------------------

--
-- Structure de la table `appareil`
--

CREATE TABLE IF NOT EXISTS `appareil` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `REFERENCE` varchar(255) DEFAULT NULL,
  `FK_MARQUE` int(11) DEFAULT NULL,
  `FK_TYPE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_REFERENCE_APPAREIL` (`REFERENCE`),
  KEY `FK_MARQUE_APPAREIL` (`FK_MARQUE`),
  KEY `FK_TYPE_APPAREIL` (`FK_TYPE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2508;




-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(128) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NOM` (`NOM`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=355;


-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_ADRESSE_FACTURATION` int(11) NOT NULL,
  `FK_ADRESSE_LIVRAISON` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_PIECE_COMMANDE` (`FK_PIECE`),
  KEY `FK_ADRESSE_FACTURATION` (`FK_ADRESSE_FACTURATION`),
  KEY `FK_ADRESSE_LIVRAISON` (`FK_ADRESSE_LIVRAISON`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0;

-- --------------------------------------------------------

--
-- Structure de la table `installer`
--

CREATE TABLE IF NOT EXISTS `installer` (
  `FK_PIECE` int(11) NOT NULL,
  `FK_APPAREIL` int(11) NOT NULL,
  KEY `FK_2xmdus772j94eqi1xnxyfappe` (`FK_APPAREIL`),
  KEY `FK_4lihgjebgepl2fivyfe61wbd1` (`FK_PIECE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `marque`
--

CREATE TABLE IF NOT EXISTS `marque` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(128) NOT NULL,
  `VISIBLE` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NOM` (`NOM`),
  UNIQUE KEY `UK_4heduwamwbj4i2yqwnweqkvmx` (`NOM`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=129 ;

-- --------------------------------------------------------

--
-- Structure de la table `piece`
--

CREATE TABLE IF NOT EXISTS `piece` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESCRIPTION` varchar(128) DEFAULT NULL,
  `PRIX` decimal(13,2) DEFAULT NULL,
  `REFERENCE` varchar(128) NOT NULL,
  `FK_CATEGORIE` int(11) NOT NULL,
  `FK_PIECE` int(11) DEFAULT NULL,
  `QTY` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `REFERENCE` (`REFERENCE`),
  UNIQUE KEY `UK_8s7dgfw92ecbavmuyknm6iuc8` (`REFERENCE`),
  KEY `I_FK_CATEGORIE` (`FK_CATEGORIE`),
  KEY `I_FK_PIECE` (`FK_PIECE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12501 ;


-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(128) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NOM` (`NOM`),
  UNIQUE KEY `UK_a752ebu3c9k9ot36rbefs9ewv` (`NOM`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=98 ;



-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(128) NOT NULL,
  `MOTDEPASSE` varchar(128) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NOM` (`NOM`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;



--
-- Contraintes pour les tables exportées
--


--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `FK_gw44e87pkj9myn5dbut33tbhh` FOREIGN KEY (`FK_PIECE`) REFERENCES `piece` (`ID`),
  ADD CONSTRAINT `FK_p2748ujtdqp28gw03ncedxigc` FOREIGN KEY (`FK_COMMANDE`) REFERENCES `adresse` (`ID`);

--
-- Contraintes pour la table `installer`
--
ALTER TABLE `installer`
  ADD CONSTRAINT `FK_2xmdus772j94eqi1xnxyfappe` FOREIGN KEY (`FK_APPAREIL`) REFERENCES `appareil` (`ID`),
  ADD CONSTRAINT `FK_4lihgjebgepl2fivyfe61wbd1` FOREIGN KEY (`FK_PIECE`) REFERENCES `piece` (`ID`);

--
-- Contraintes pour la table `piece`
--
ALTER TABLE `piece`
  ADD CONSTRAINT `FK_1faxruqnvc4y973x93xdsu3et` FOREIGN KEY (`FK_CATEGORIE`) REFERENCES `categorie` (`ID`),
  ADD CONSTRAINT `FK_4wa4u6o6gxtojpuu2uqrose19` FOREIGN KEY (`FK_PIECE`) REFERENCES `piece` (`ID`),
  ADD CONSTRAINT `piece_ibfk_1` FOREIGN KEY (`FK_CATEGORIE`) REFERENCES `categorie` (`ID`),
  ADD CONSTRAINT `piece_ibfk_2` FOREIGN KEY (`FK_PIECE`) REFERENCES `piece` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
